using AspNetCoreGeneratedDocument;
using BoardApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace BoardApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpGet]
        public ViewResult AddBoard()
        {
            return View();
        }

        [HttpPost]
        public ViewResult AddBoard(Board board)
        {
            if (ModelState.IsValid)
            {
                Repository.AddBoard(board);
                return View("BoardAdded", board);
            }
            return View();
           
        }

        public ViewResult ListBoards()
        {
            return View(Repository.Boards);
        }
    }
}
