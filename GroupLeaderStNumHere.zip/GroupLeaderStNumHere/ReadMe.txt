Comments added, fixed the key issue.
See extra comments for clarification.
Add Group Leader name and group student numbers at top of .cs files.
Double check re-use comments