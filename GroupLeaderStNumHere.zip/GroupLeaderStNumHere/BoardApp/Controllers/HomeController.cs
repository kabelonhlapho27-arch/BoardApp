//   Group leader name   :     
//   Group Student nrs   :   219005935;  
//   Assignment   nr     :   SOD226C Practical Assessment 1 � 2026 
//   Purpose             :   The purpose of this program is to list, edit, delete and keep track of
//                           microcontroller development boards through the use of a web app taht mannages
//                           information about them.

using System.Diagnostics;
using BoardApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace BoardApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;        

        public HomeController(ILogger<HomeController> logger)
        {
            //
            //Method Name       : HomeController(ILogger<HomeController> logger) 
            //Purpose           : Initialize logger service
            //Re-use            : none
            //Method Parameters : ILogger<HomeController> logger
            //Output Type       : none
            //
            _logger = logger;
        }//end HomeController

        public IActionResult Index()
        {
            //
            //Method Name       : IActionResult Index() 
            //Purpose           : Display home page
            //Re-use            : none
            //Method Parameters : none
            //Output Type       : IActionResult
            //
            return View();
        }//end Index()

        public IActionResult Privacy()
        {
            //
            //Method Name       : IActionResult Privacy() 
            //Purpose           : Display private policy page
            //Re-use            : none
            //Method Parameters : none
            //Output Type       : IactionResult
            //
            return View();
        }//end Privacy()           

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            //
            //Method Name       : IActionResult Error() 
            //Purpose           : Display error page
            //Re-use            : none
            //Method Parameters : none
            //Output Type       : IactionResult
            //
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }//end Error()
    }//end class HomeController : Controller
}//end namespace BoardApp.Controllers