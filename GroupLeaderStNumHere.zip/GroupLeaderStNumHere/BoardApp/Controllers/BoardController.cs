﻿//   Group leader name   :     
//   Group Student nrs   :   219005935;  
//   Assignment   nr     :   SOD226C Practical Assessment 1 · 2026 
//   Purpose             :   The purpose of this program is to list, edit, delete and keep track of
//                           microcontroller development boards through the use of a web app taht mannages
//                           information about them.

using BoardApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace BoardApp.Controllers
{
    public class BoardController : Controller
    {              
        public ViewResult Index()
        {
            //
            //Method Name       : ViewResult Index() 
            //Purpose           : Display list of microcontrollers
            //Re-use            : none
            //Method Parameters : none
            //Output Type       : ViewResult
            //
            return View(Repository.Boards);
        }//end Index()
        public ViewResult Details(string id)
        {
            //
            //Method Name       : ViewResult Details(string id) 
            //Purpose           : Display the details view
            //Re-use            : none
            //Method Parameters : string id
            //Output Type       : ViewResult
            //
            Board? board = Repository.GetByBoardCode(id);                    //team used var here instead of Board?
            return View(board);
        }//end Details
        [HttpGet]
        public ViewResult Create()
        {
            //
            //Method Name       : ViewResult Create() 
            //Purpose           : Display the create new board view
            //Re-use            : none
            //Method Parameters : none
            //Output Type       : ViewResult
            //
            return View();
        }//end Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ViewResult Create(Board board)
        {
            //
            //Method Name       : ViewResult Create(Board board) 
            //Purpose           : Validate and save new board
            //Re-use            : none
            //Method Parameters : Board board
            //Output Type       : ViewResult
            //
            if (ModelState.IsValid)
            {
                Repository.AddBoard(board);
                ViewBag.SuccessMessage = $"Board {board.BoardCode} was added.";
            }
            return View(board);
        }//end Create(Board board)
        [HttpGet]
        public ViewResult Edit(string id)
        {
            //
            //Method Name       : ViewResult Edit(string id) 
            //Purpose           : Display the edit view
            //Re-use            : none
            //Method Parameters : string id
            //Output Type       : ViewResult
            //
            Board? board = Repository.GetByBoardCode(id);                   //team used var here instead of Board?
            return View(board);
        }//end Edit(string id)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ViewResult Edit(Board board)
        {
            //
            //Method Name       : ViewResult Edit(Board board) 
            //Purpose           : Vaildate and save changes
            //Re-use            : none
            //Method Parameters : Board board
            //Output Type       : ViewResult
            //
            if (ModelState.IsValid)
            {
                Repository.UpdateBoard(board);
                ViewBag.SuccessMessage = $"Board {board.BoardCode} was updated.";
            }
            return View(board);
        }//end Edit(Board board)
        [HttpGet]
        public ViewResult Delete(string id)
        {
            //
            //Method Name       : ViewResult Delete(string id) 
            //Purpose           : Display the delete view
            //Re-use            : none
            //Method Parameters : string id
            //Output Type       : ViewResult
            //
            Board? board = Repository.GetByBoardCode(id);                           //team used var here instead of Board?
            return View(board);
        }//end Delete(string id)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ViewResult Delete(Board board)
        {
            //
            //Method Name       : ViewResult Delete(Board board) 
            //Purpose           : to delete a microcontoller form the repository
            //Re-use            : none
            //Method Parameters : Board board
            //Output Type       : ViewResult
            //
            Repository.RemoveBoard(board.BoardCode);
            ViewBag.SuccessMessage = $"Board {board.BoardCode} was deleted.";
            return View(board);
        }//end Delete(Board board)
    }//end class BoardController : Controller
}//end namespace BoardApp.Controllers