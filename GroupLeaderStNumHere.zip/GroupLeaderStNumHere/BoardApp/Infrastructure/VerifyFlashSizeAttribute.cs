﻿//   Group leader name   :     
//   Group Student nrs   :   219005935;  
//   Assignment   nr     :   SOD226C Practical Assessment 1 · 2026 
//   Purpose             :   The purpose of this program is to list, edit, delete and keep track of
//                           microcontroller development boards through the use of a web app taht mannages
//                           information about them.

using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace BoardApp.Infrastructure
{
    public class VerifyFlashSizeAttribute : Attribute, IModelValidator
    {
        public bool IsRequired => true;     
        public string ErrorMessage { get; set; } = "Valid flash sizes in KB are: 16, 32, 64, 128, 256, 512, 1024, 2048, 4096";
        private readonly List<int> validFlashSizes = new List<int>
        {           
            16, 32, 64, 128, 256, 512, 1024, 2048, 4096
        };//end list

        public IEnumerable<ModelValidationResult> Validate(ModelValidationContext context)
        {
            //
            //Method Name       : Validate(ModelValidationContext context) 
            //Purpose           : Validate user input matcahes allowed range
            //Re-use            : none
            //Method Parameters : ModelValidationContext context
            //Output Type       : IEnumerable<ModelValidationResult>
            //
            int? value = context.Model as int?;
            //Fail if null or not in the allowed set
            if (value == null || !validFlashSizes.Contains (value.Value))
            {
                return new List<ModelValidationResult>
                {
                    new ModelValidationResult("", ErrorMessage)
                };//end return
            }//end if
            //pass if valid 
            return Enumerable.Empty<ModelValidationResult>();
        }//end Validate(ModelValidationContext context)
    }//end class VerifyFlashSizeAttribute : Attribute, IModelValidator
}//end namespace BoardApp.Infrastructure