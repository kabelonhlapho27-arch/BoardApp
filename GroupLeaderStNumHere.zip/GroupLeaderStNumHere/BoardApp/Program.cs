//   Group leader name   :     
//   Group Student nrs   :   219005935;  
//   Assignment   nr     :   SOD226C Practical Assessment 1 � 2026 
//   Purpose             :   The purpose of this program is to list, edit, delete and keep track of
//                           microcontroller development boards through the use of a web app that mannages
//                           information about them.

namespace BoardApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //
            //Name              : void Main(string[] args) 
            //Purpose           : Main entry point
            //Re-use            : none
            //Input Parameters  : string[] args
            //Output Type       : none
            //

            var builder = WebApplication.CreateBuilder(args);
            // Add services to the container.
            builder.Services.AddControllersWithViews();
            var app = builder.Build();
            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }//enf if

            app.UseStaticFiles();
            app.UseRouting();
            app.UseAuthorization();
            app.MapControllerRoute(name: "default",pattern: "{controller=Home}/{action=Index}/{id?}");
            app.Run();
        }//end Main
    }//end class Program
}//end namespace BoardApp