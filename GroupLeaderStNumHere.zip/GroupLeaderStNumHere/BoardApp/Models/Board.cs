﻿//   Group leader name   :     
//   Group Student nrs   :   219005935;  
//   Assignment   nr     :   SOD226C Practical Assessment 1 · 2026 
//   Purpose             :   The purpose of this program is to list, edit, delete and keep track of
//                           microcontroller development boards through the use of a web app taht mannages
//                           information about them.

using System.ComponentModel.DataAnnotations;
using BoardApp.Infrastructure;

namespace BoardApp.Models
{
    public class Board
    {
        //Properties
        [Key]                                                                                       //team put key attribute on the make, see worksheet 2 section 2
        [Required(ErrorMessage = "The board code is required.")]
        [StringLength(4, MinimumLength = 4, ErrorMessage = "The board code must have a length of 4.")]
        [Display(Name = "Board code")]
        public string BoardCode { get; set; }

        [Required(ErrorMessage = "The board manufacturer is required.")]
        [Display(Name = "Manufacturer")]
        public string Make { get; set; }

        [Required(ErrorMessage = "The board model is required.")]
        [Display(Name = "Model")]
        public string Model { get; set; }

        [Required(ErrorMessage = "The flash size is required.")]
        //[Range(16, 4096, ErrorMessage = "The flash size must be between 16 and 4096 inclusive.")]
        [VerifyFlashSize]
        [Display(Name = "Flash (KB)")]        
        public int? FlashKb { get; set; }

        [Required(ErrorMessage = "The price is required.")]
        [Range(1.00, 5000.00, ErrorMessage = "The price must be between R1.00 and R5000.00 inclusive.")]
        [DisplayFormat(DataFormatString = "{0:0.00}", ApplyFormatInEditMode = false)]                        //team used {0:N2} not sure which is best
        [Display(Name = "Price (R)")]
        public decimal? Price { get; set; }
        
        public Board() 
        {
            //
            //Method Name       : Board()  
            //Purpose           : Defualt constructor
            //Re-use            : none
            //Method Parameters : none
            //Output Type       : none
            //
        }//end Board()
        public Board(string boardCode,string make,string model,int flashKb,decimal price) 
        {
            //
            //Method Name       : Board(string boardCode,string make,string model,int flashKb,decimal price) 
            //Purpose           : Overloaded constructor, initalize paramitors
            //Re-use            : none
            //Method Parameters : string boardCode,string make,string model,int flashKb,decimal price
            //Output Type       : none
            //
            BoardCode = boardCode;
            Make = make;
            Model = model;
            FlashKb = flashKb;
            Price = price;
        }//end Board(string boardCode,string make,string model,int flashKb,decimal price)        
        public override string ToString()
        {
            //
            //Method Name       : ToString() 
            //Purpose           : override string for microcontorller detals
            //Re-use            : none
            //Method Parameters : none
            //Output Type       : string
            //
            return $"{BoardCode}: {Make} {Model} with {FlashKb} KB flash at R{Price:0.00}";     //team used a diffrent string here, see worksheet 1 task 2.2
        }//end  ToString()
    }//end class Board
}//end namespace BoardApp.Models