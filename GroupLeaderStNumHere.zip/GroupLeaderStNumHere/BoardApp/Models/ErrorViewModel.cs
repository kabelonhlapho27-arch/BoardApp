//   Group leader name   :     
//   Group Student nrs   :   219005935;  
//   Assignment   nr     :   SOD226C Practical Assessment 1 � 2026 
//   Purpose             :   The purpose of this program is to list, edit, delete and keep track of
//                           microcontroller development boards through the use of a web app taht mannages
//                           information about them.

namespace BoardApp.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }    
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }//end class ErrorViewModel
}//end namespace BoardApp.Models