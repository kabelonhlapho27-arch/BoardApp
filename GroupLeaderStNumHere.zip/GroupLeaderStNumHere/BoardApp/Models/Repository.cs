﻿//   Group leader name   :     
//   Group Student nrs   :   219005935;  
//   Assignment   nr     :   SOD226C Practical Assessment 1 · 2026 
//   Purpose             :   The purpose of this program is to list, edit, delete and keep track of
//                           microcontroller development boards through the use of a web app taht mannages
//                           information about them.

namespace BoardApp.Models
{
    public static class Repository
    {
        private static List<Board> boards = new List<Board>();      
        static Repository()
        {
            boards = new List<Board>()
            {
                new Board("1001", "Espressif", "ESP32-WROOM-32", 4096, 129.00m),
                new Board("1002", "Espressif", "ESP32-C3-MINI-1", 4096, 99.00m),
                new Board("1003", "STMicroelectronics", "STM32F103C8T6", 64, 75.00m),
                new Board("1004", "STMicroelectronics", "STM32F411CEU6", 512, 145.00m),
                new Board("1005", "Microchip", "ATmega328P", 32, 89.00m),
                new Board("1006", "Microchip", "ATmega2560", 256, 199.00m),
                new Board("1007", "WCH", "CH32V003F4P6", 16, 29.00m),
                new Board("1008", "Raspberry Pi", "Pico", 2048, 89.00m),
                new Board("1009", "Espressif", "ESP-01S", 1024, 65.00m),
                new Board("1010", "CUTfree", "CV32-BFN-01", 128, 49.00m)
            };
        }
        public static IEnumerable<Board> Boards
        {
            //
            //Method Name       : IEnumerable<Board> Boards
            //Purpose           : Return list of boards
            //Re-use            : none
            //Method Parameters : none
            //Output Type       : IEnumerable<Board>
            //
            get { return boards; }
        }//end Boards
        public static void AddBoard(Board board)
        {
            //
            //Method Name       : void AddBoard(Board board)
            //Purpose           : Insert a new board object to the list
            //Re-use            : none
            //Method Parameters : Board board
            //Output Type       : void
            //
            boards.Add(board);
        }//end void AddBoard
        public static Board? GetByBoardCode(string boardCode)
        {
            //
            //Method Name       : Board? GetBoardCode(string boardCode) 
            //Purpose           : Get the board code of an object
            //Re-use            : none
            //Method Parameters : string boardCode
            //Output Type       : Board?
            //
            return boards.FirstOrDefault(b => b.BoardCode == boardCode);
        }//end GetBoardCode
        public static void RemoveBoard(string boardCode)
        {
            //
            //Method Name       : RemoveBoard(string boardCode) 
            //Purpose           : Use boardcode to locate and remove a board
            //Re-use            : none
            //Method Parameters : string boardCode
            //Output Type       : void
            //
            var boardToRemove = GetByBoardCode(boardCode);
            if (boardToRemove != null)
            {
                boards.Remove(boardToRemove);
            }//end if
        }//end void RemoveBoard
        public static void UpdateBoard(Board updateBoard)
        {
            //
            //Method Name       : void UpdateBoard(Board updateBoard) 
            //Purpose           : Overwrite data of existing board
            //Re-use            : none
            //Method Parameters : Board updateBoard
            //Output Type       : void
            //
            if (updateBoard == null)
            {
                return;
            }//end if
            var exsistingBoard = GetByBoardCode(updateBoard.BoardCode);
            if (exsistingBoard != null)
            {
                exsistingBoard.Make = updateBoard.Make;
                exsistingBoard.Model = updateBoard.Model;
                exsistingBoard.FlashKb = updateBoard.FlashKb;
                exsistingBoard.Price = updateBoard.Price;
            }//end if
        }//end void UpdateBoard
    }//end static class Repository
}//end namespace BoardApp.Models